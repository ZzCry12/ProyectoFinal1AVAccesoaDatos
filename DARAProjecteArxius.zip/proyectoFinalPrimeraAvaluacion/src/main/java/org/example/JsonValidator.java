package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import java.io.IOException;
import java.io.InputStream;

public class JsonValidator {

        public static void validate() {
                try {
                        ObjectMapper mapper = new ObjectMapper();
                        JsonSchemaFactory factory = JsonSchemaFactory.byDefault();

                        InputStream schemaStream = JsonValidator.class.getResourceAsStream("/jsonschema.json");
                        InputStream jsonStream = JsonValidator.class.getResourceAsStream("/bmw.json");

                        JsonNode jsonSchema = mapper.readTree(schemaStream);
                        JsonNode jsonData = mapper.readTree(jsonStream);

                        JsonSchema schema = factory.getJsonSchema(jsonSchema);
                        ProcessingReport report = schema.validate(jsonData);

                        if (report.isSuccess()) {
                                System.out.println("Json Validado!");
                        } else {
                                System.out.println("Validación fallida, aquí estan los errores a corregir:");
                                for (ProcessingMessage message : report) {
                                        System.out.println(message);
                                }
                        }
                } catch (IOException | ProcessingException e) {
                        e.printStackTrace();
                }
        }
}
