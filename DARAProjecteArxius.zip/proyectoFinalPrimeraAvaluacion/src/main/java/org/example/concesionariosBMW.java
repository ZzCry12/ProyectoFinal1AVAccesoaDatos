package org.example;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class concesionariosBMW {
    @JsonProperty("id")
    private int id;
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("ubicacion")
    private String ubicacion;
    @JsonProperty("telefono")
    private String telefono;
    @JsonProperty("modelosDisponibles")
    private List<String> modelosDisponibles;
    public concesionariosBMW() {
    }

    public concesionariosBMW(int id, String nombre, String ubicacion, String telefono, List<String> modelosDisponibles) {
        this.id = id;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.telefono = telefono;
        this.modelosDisponibles = modelosDisponibles;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public List<String> getModelosDisponibles() {
        return modelosDisponibles;
    }

    public void setModelosDisponibles(List<String> modelosDisponibles) {
        this.modelosDisponibles = modelosDisponibles;
    }

}

