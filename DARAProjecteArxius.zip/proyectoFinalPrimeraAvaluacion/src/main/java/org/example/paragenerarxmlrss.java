package org.example;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.List;

@JacksonXmlRootElement(localName = "rss")
public class paragenerarxmlrss {
    public paragenerarxmlrss(List<modeloBMW> modeloBMWList) {
        this.modeloBMWList = modeloBMWList;
    }

    public List<modeloBMW> getModeloBMWList() {
        return modeloBMWList;
    }

    public void setModeloBMWList(List<modeloBMW> modeloBMWList) {
        this.modeloBMWList = modeloBMWList;
    }

    public paragenerarxmlrss() {
    }

    @JacksonXmlElementWrapper(localName = "modeloBMW")
    @JacksonXmlProperty(localName = "modeloBMW")
    public List<modeloBMW> modeloBMWList;

}
