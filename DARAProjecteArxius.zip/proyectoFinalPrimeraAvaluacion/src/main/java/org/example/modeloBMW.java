package org.example;

import com.fasterxml.jackson.annotation.JsonProperty;

public class modeloBMW {
    @JsonProperty("id")
    private int id;
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("tipo")
    private String tipo;
    @JsonProperty("año")
    private String año;
    @JsonProperty("precio")
    private String precio;

    public modeloBMW() {
    }

    public modeloBMW(int id, String nombre, String tipo, String año, String precio) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.año = año;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
