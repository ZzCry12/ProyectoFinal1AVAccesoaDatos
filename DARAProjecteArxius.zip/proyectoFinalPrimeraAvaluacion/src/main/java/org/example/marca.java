package org.example;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class marca {
    @JsonProperty("titulo")
    private String titulo;
    @JsonProperty("descripcion")
    private String descripcion;
    @JsonProperty("data_inici")
    private String data_inici;
    @JsonProperty("data_fi")
    private String data_fi;
    @JsonProperty("modelosBMW")
    public List<modeloBMW> modeloBMWS;
    @JsonProperty("concesionariosBMW")
    public List<concesionariosBMW> concesionariosBMWS;
    public marca() {
    }

    public marca(String titulo, String descripcion, String data_inici, String data_fi, List<modeloBMW> modeloBMWS, List<concesionariosBMW> concesionariosBMWS) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.data_inici = data_inici;
        this.data_fi = data_fi;
        this.modeloBMWS = modeloBMWS;
        this.concesionariosBMWS = concesionariosBMWS;
    }
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getData_inici() {
        return data_inici;
    }

    public void setData_inici(String data_inici) {
        this.data_inici = data_inici;
    }

    public String getData_fi() {
        return data_fi;
    }

    public void setData_fi(String data_fi) {
        this.data_fi = data_fi;
    }

    public List<modeloBMW> getModeloBMWS() {
        return modeloBMWS;
    }

    public void setModeloBMWS(List<modeloBMW> modeloBMWS) {
        this.modeloBMWS = modeloBMWS;
    }

    public List<concesionariosBMW> getConcesionariosBMWS() {
        return concesionariosBMWS;
    }

    public void setMarcaBMWS(List<concesionariosBMW> concesionariosBMWS) {
        this.concesionariosBMWS = concesionariosBMWS;
    }


}
