package org.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.rometools.rome.feed.synd.*;
import com.rometools.rome.io.FeedException;
import com.rometools.rome.io.SyndFeedOutput;
import com.rometools.rome.io.WireFeedOutput;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.IContext;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import javax.naming.Context;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            deserializarJson();
            JsonValidator.validate();
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(new File("D:\\SUPERIOR\\2dam\\jaume\\lecturasax\\proyectoFinalPrimeraAvaluacion\\src\\main\\resources\\bmw.json"));

            JsonNode modelosNode = jsonNode.get("modelosBMW");
            JsonNode concesionariosNode = jsonNode.get("concesionariosBMW");
            List<modeloBMW> modelosList = objectMapper.readValue(modelosNode.toString(), new TypeReference<List<modeloBMW>>(){});
            List<concesionariosBMW> concesionariosList = objectMapper.readValue(concesionariosNode.toString(), new TypeReference<List<concesionariosBMW>>(){});

            TemplateEngine templateEngine = new TemplateEngine();
            ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
            templateResolver.setPrefix("templates/");
            templateResolver.setSuffix(".html");
            templateEngine.setTemplateResolver(templateResolver);

            org.thymeleaf.context.Context context = new org.thymeleaf.context.Context();
            context.setVariable("modelosBMW", modelosList);
            context.setVariable("concesionariosBMW", concesionariosList);

            String contenidoModelos = templateEngine.process("modelos", context);
            String contenidoConcesionarios = templateEngine.process("concesionarios", context);

            escribirHTML(contenidoModelos, "src/main/resources/web/index.html");
            escribirHTML(contenidoConcesionarios, "src/main/resources/web/concesionarios.html");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void escribirHTML(String contenidoHTML, String nombreArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            writer.write(contenidoHTML);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void deserializarJson() {
        try {
            ObjectMapper fitxer = new ObjectMapper();
            marca marca = fitxer.readValue(new File("D:\\SUPERIOR\\2dam\\jaume\\lecturasax\\proyectoFinalPrimeraAvaluacion\\src\\main\\resources\\bmw.json"), marca.class);
            System.out.println("------------------------------Descripcion JSON----------------------------------");
            System.out.println("Titol: " + marca.getTitulo());
            System.out.println("Descripción: " + marca.getDescripcion());
            System.out.println("Data Inicio: " + marca.getData_inici());
            System.out.println("Data fin: " + marca.getData_fi());
            System.out.println("------------------------------Modelos BMW----------------------------------");

            for (modeloBMW modelo : marca.getModeloBMWS()) {
                System.out.println("id coche: " + modelo.getId());
                System.out.println("Nombre: " + modelo.getNombre());
                System.out.println("Tipo " + modelo.getTipo());
                System.out.println("Año: " + modelo.getAño());
                System.out.println("Precio: " + modelo.getPrecio());
                System.out.println();
            }

            System.out.println("------------------------------Concesionarios----------------------------------");

            for (concesionariosBMW concesionario : marca.getConcesionariosBMWS()) {
                System.out.println("ID concesionario: " + concesionario.getId());
                System.out.println("Nombre: " + concesionario.getNombre());
                System.out.println("Ubicacion: " + concesionario.getUbicacion());
                System.out.println("telefono: " + concesionario.getTelefono());
                System.out.println("Modelos disponibles: " + concesionario.getModelosDisponibles());
                System.out.println();
            }
            System.out.println("-----------------------------------------------------------------");

            SyndFeed feed = new SyndFeedImpl();
            feed.setFeedType("rss_2.0");

            feed.setTitle("DARIO RATA RSS BMWS");
            feed.setDescription("PROYECTO PRIMERA AVALUACION");
            feed.setLink("D:\\SUPERIOR\\2dam\\jaume\\lecturasax\\proyectoFinalPrimeraAvaluacion\\src\\main\\resources\\web\\index.html");

            List<SyndEntry> entries = new ArrayList<>();

            for (modeloBMW modelo : marca.getModeloBMWS()) {
                SyndEntry entry = new SyndEntryImpl();
                entry.setTitle(modelo.getNombre());

                SyndContent description = new SyndContentImpl();
                description.setType("text/plain");
                description.setValue("Tipo: " + modelo.getTipo() + ", Año: " + modelo.getAño() + ", Precio: " + modelo.getPrecio());

                entry.setDescription(description);

                entries.add(entry);
            }

            feed.setEntries(entries);

            SyndFeedOutput output = new SyndFeedOutput();
            output.output(feed, new FileWriter("src/main/XMLRSS/archivo_rss.xml"));

        } catch (IOException | FeedException ex) {
            ex.printStackTrace();
        }
    }

}